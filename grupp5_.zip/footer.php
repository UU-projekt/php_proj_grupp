<?php
echo '

<div id="footer-container">
      
      <img src="img/footer-photo.avif" id="footer-img">
      
      <div class="footer-item">
            <p><b>Länkar</b></p>
            <a href="#">Om oss</a>
            <a href="#">Kontakt</a>
            <a href="#">Nyheter</a>
            <a href="#">Press</a>
      </div>

      <div class="footer-item">
            <p><b>Kategorier</b></p>
            <a href="/adfsgd">Sittmöbler</a>
            <a href="/adfsgd">Bord</a>
            <a href="/adfsgd">Sängar</a>
            <a href="/adfsgd">Förvaring</a>
            <a href="/adfsgd">Utemöbler</a>
            <a href="/adfsgd">Övrigt</a>
      </div>

</div>

<div id="footer-below"> 
      <p>Välkommen till Lilla Vardagsrummet<br>
      © 2024 Lilla Vardagsrummet.</p>
</div>
';


?>