<?php



echo '<li class="menu-item">Kategorier
<ul id="categories-drop-down-menu">
      <li class="drop-down-item">
      <a href="categories/showcategory.php?category_id=1">Sittmöbler</a>
      </li>
      <li class="drop-down-item">
      <a href="categories/showcategory.php?category_id=2">Bord</a>
      </li>
      <li class="drop-down-item">
      <a href="categories/showcategory.php?category_id=3">Sängar</a>
      </li>
      <li class="drop-down-item">
      <a href="categories/showcategory.php?category_id=4">Förvaring</a>
      </li>
      <li class="drop-down-item">
      <a href="categories/showcategory.php?category_id=5">Utemöbler</a>
      </li>
      <li class="drop-down-item">
      <a href="categories/showcategory.php?category_id=6">Övrigt</a>
      </li>
</ul>
</li>';

?>